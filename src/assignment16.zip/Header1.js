function Header1() {
    return (
        <>
          <div className="head"><h1>Fruits Shopee</h1></div>
          <marquee>Health is Wealth</marquee>
        </>  
)}
export default Header1


