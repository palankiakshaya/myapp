import React from 'react'
import Header1 from './Header1'
import Footer from './Footer'
import './App.css'

export default function App6() {
    return (
      <div>
        <Header1/>
      <div className='container'>
          <div className='s'>
              <img src="https://th.bing.com/th/id/R.ab6c56605d3aa4bab914b20c75fdb213?rik=tDMv9WRYvt2OeA&riu=http%3a%2f%2fweknowyourdreams.com%2fimages%2fmango%2fmango-09.jpg&ehk=dv%2b5PHEII27LKRaPpFh5E2wEmhnx4NNH3UpGsS6wZ70%3d&risl=&pid=ImgRaw&r=0"></img>
              <br></br>
              <h3>Mango</h3>
              <h3>price : 300</h3>
              <button>Add</button>
              
          </div>
          <div className='a'>
              <img src="https://media.istockphoto.com/id/1157946861/photo/red-berry-strawberry-isolated.jpg?s=612x612&w=0&k=20&c=HyxZMbI_e-vDJbrzZkTz5zWCAo1mBEzWbvVlyigbi-E="></img>
              <br></br>
              <h3>Stawberry</h3>
              <h3>price : 300</h3>
              <button>Add</button>
             
          </div>
          <div className='f'>
              <img src="https://th.bing.com/th/id/OIP.oVeiT4LzCXtk9JVBfN-gMQHaE7?rs=1&pid=ImgDetMain"></img>
              <br></br>
              <h3>Orange</h3>
              <h3>price : 300</h3>
              <button>Add</button>
          </div>
  
      </div>
      <div className='container'>
          <div className='s'>
              <img src="https://media.istockphoto.com/id/172862474/photo/pineapple-a-ripe-fresh-fruit-food-whole-isolated-on-white.jpg?s=612x612&w=0&k=20&c=NIXw8LVGZ3doNXMn9st9nuyL8WFqPNC4VxPf8V4xf7w="></img>
              <br></br>
              <h3>Pineapple</h3>
              <h3>price : 300</h3>
              <button>Add</button>
              
          </div>
          <div className='a'>
              <img src="https://th.bing.com/th/id/OIP.KNHJ3Zj5fMpWo1Hhs97uDwHaF7?rs=1&pid=ImgDetMain"></img>
              <br></br>
              <h3>Mango</h3>
              <h3>price : 300</h3>
              <button>Add</button>
             
          </div>
          <div className='f'>
              <img src="https://media.istockphoto.com/id/913533868/photo/sugar-apple-isolated-on-white.jpg?s=612x612&w=0&k=20&c=wxIq7r4MVvsQ7a4Wp97pWX9HLEQRSr0pyQTokgasYu0="></img>
              <br></br>
              <h3>Custard Apple</h3>
              <h3>price : 200</h3>
              <button>Add</button>
              
          </div>
  
      </div>
  
  
      </div>
    )
  }
